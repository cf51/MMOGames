//allows the client to connect to the active socket
var socket = io.connect("http://localhost:3000");